This is a skeleton to help get my students started with their lab: uploading files and fetching files.


to run apps

client:

open terminal to the client folder
npm i
npm run dev

open a new terminal to the server folder
npm i
npm run dev


You should have 2 terminals open, running React and Express


TODO:

Setup functions to fetch:

GET - Fetch Multiple Random Images
POST - Save Multiple Images
GET - Dog API -> Call to API directly and Display the Image in react
POST - Allow the user to save the Dog image to the Server

Server:
Setup the routes and functions for:

saving multiple images - Check the website npm for multer, they have a function for you "upload.array"
Ill show some things at the end of class.

